// Basic JS: mobile menu + search filtering across .search-item elements
document.addEventListener('DOMContentLoaded', function(){
  var toggle = document.getElementById('menuToggle');
  var nav = document.getElementById('mainNav');
  toggle && toggle.addEventListener('click', function(){ nav.classList.toggle('active'); });

  var searchInput = document.getElementById('searchInput');
  var searchButton = document.getElementById('searchButton');
  function doSearch(){
    var q = (searchInput.value || '').toLowerCase().trim();
    if(!q) {
      document.querySelectorAll('.search-item').forEach(function(el){ el.style.display = ''; });
      return;
    }
    document.querySelectorAll('.search-item').forEach(function(el){
      var tags = el.getAttribute('data-tags') || '';
      var text = (el.innerText || '') + ' ' + tags;
      if(text.toLowerCase().indexOf(q) !== -1) el.style.display = '';
      else el.style.display = 'none';
    });
  }
  searchButton && searchButton.addEventListener('click', doSearch);
  searchInput && searchInput.addEventListener('keyup', function(e){ if(e.key === 'Enter') doSearch(); });
});