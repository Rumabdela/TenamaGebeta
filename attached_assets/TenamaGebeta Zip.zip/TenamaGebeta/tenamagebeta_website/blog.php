<?php include 'header.php'; ?>
<section class="container">
    <h2 class="section-title">Blog</h2>
    <div class="blog-grid">
        <div class="blog-post">
            <div class="blog-image"><img src="/assets/blog1.jpg" alt="Blog"></div>
            <div class="blog-content">
                <h3>Keeping Traditional Foods Healthy</h3>
                <p>Short article intro... <a href="#">Read more</a></p>
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>